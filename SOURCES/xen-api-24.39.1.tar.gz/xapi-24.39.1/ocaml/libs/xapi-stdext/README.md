Deprecated misc utility functions
=================================

These utility functions are used by several other services. Much of this
should be replaced with other libraries such as
  * Stdlib
  * Bos

Eventually this library should disappear.

In the meantime documentation can be found at http://xapi-project.github.io/stdext/index.html
