# The XCP inventory library

Maintains a database of key-value pairs at a specific location in the
filesystem.
