Round-Robin Datasources (RRDs) for OCaml.
