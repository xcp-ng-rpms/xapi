# API Reference

Version **@xapi-version@**

-  [Classes](@root@management-api/classes.html)
-  [Relationships Between Classes](@root@management-api/relationships-between-classes.html)
-  [Types](@root@management-api/types.html)
-  [ErrorHandling](@root@management-api/api-errors.html)
