+++
title = "XenServer 7.6"
layout = "release"
type = "xenapi"
release = "lima"
weight = 44
+++
