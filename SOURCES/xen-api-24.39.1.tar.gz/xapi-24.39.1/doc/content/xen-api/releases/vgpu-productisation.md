+++
title = "XenServer 6.2 SP1"
layout = "release"
type = "xenapi"
release = "vgpu-productisation"
weight = 56
+++
