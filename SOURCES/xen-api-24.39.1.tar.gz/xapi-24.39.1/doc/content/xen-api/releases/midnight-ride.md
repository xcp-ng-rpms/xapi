+++
title = "XenServer 5.6"
layout = "release"
type = "xenapi"
release = "midnight-ride"
weight = 62
+++
