+++
title = "XenServer 5.0"
layout = "release"
type = "xenapi"
release = "orlando"
weight = 65
+++
