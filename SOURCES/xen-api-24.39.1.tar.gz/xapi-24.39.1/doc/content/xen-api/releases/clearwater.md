+++
title = "XenServer 6.2"
layout = "release"
type = "xenapi"
release = "clearwater"
weight = 58
+++
