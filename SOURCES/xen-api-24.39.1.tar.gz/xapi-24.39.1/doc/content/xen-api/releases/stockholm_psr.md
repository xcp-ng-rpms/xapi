+++
title = "Citrix Hypervisor 8.2 Hotfix 2"
layout = "release"
type = "xenapi"
release = "stockholm_psr"
weight = 40
+++
