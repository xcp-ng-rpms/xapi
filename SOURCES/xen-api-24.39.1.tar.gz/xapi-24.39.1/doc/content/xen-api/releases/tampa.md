+++
title = "XenServer 6.1"
layout = "release"
type = "xenapi"
release = "tampa"
weight = 59
+++
