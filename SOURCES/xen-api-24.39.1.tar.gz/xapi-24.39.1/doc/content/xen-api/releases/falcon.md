+++
title = "XenServer 7.2"
layout = "release"
type = "xenapi"
release = "falcon"
weight = 48
+++
