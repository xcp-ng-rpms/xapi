+++
title = "XenServer 6.2 SP1 Tech-Preview"
layout = "release"
type = "xenapi"
release = "vgpu-tech-preview"
weight = 57
+++
