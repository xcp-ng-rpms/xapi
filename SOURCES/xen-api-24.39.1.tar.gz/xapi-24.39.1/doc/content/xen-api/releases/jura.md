+++
title = "XenServer 7.4"
layout = "release"
type = "xenapi"
release = "jura"
weight = 46
+++
