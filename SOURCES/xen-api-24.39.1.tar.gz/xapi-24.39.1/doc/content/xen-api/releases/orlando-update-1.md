+++
title = "XenServer 5.0 Update 1"
layout = "release"
type = "xenapi"
release = "orlando-update-1"
weight = 64
+++
