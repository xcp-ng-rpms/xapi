+++
title = "XenServer 4.0"
layout = "release"
type = "xenapi"
release = "rio"
weight = 68
+++
