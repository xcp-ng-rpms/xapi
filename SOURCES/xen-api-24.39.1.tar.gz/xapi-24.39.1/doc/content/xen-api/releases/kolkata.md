+++
title = "XenServer 7.5"
layout = "release"
type = "xenapi"
release = "kolkata"
weight = 45
+++
