+++
title = "XenServer 6.5"
layout = "release"
type = "xenapi"
release = "creedence"
weight = 53
+++
