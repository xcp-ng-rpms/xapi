+++
title = "XenServer 7.1"
layout = "release"
type = "xenapi"
release = "ely"
weight = 49
+++
