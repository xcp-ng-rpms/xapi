+++
title = "XenServer 6.0"
layout = "release"
type = "xenapi"
release = "boston"
weight = 60
+++
