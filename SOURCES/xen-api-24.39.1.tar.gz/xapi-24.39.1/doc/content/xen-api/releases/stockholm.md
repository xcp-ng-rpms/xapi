+++
title = "Citrix Hypervisor 8.2"
layout = "release"
type = "xenapi"
release = "stockholm"
weight = 41
+++
