+++
title = "Citrix Hypervisor 8.1"
layout = "release"
type = "xenapi"
release = "quebec"
weight = 42
+++
