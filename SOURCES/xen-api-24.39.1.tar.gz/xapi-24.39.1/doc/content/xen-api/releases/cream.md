+++
title = "XenServer 6.5 SP1"
layout = "release"
type = "xenapi"
release = "cream"
weight = 52
+++
