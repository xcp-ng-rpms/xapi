+++
title = "XenServer 8 Preview"
layout = "release"
type = "xenapi"
release = "nile-preview"
weight = 39
+++
