+++
title = "XenServer 6.2 SP1 Hotfix 4"
layout = "release"
type = "xenapi"
release = "clearwater-felton"
weight = 55
+++
