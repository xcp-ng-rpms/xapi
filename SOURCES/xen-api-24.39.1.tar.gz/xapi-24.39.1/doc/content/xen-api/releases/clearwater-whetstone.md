+++
title = "XenServer 6.2 SP1 Hotfix 11"
layout = "release"
type = "xenapi"
release = "clearwater-whetstone"
weight = 54
+++
