+++
title = "Citrix Hypervisor 8.0"
layout = "release"
type = "xenapi"
release = "naples"
weight = 43
+++
