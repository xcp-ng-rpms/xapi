+++
title = "XenServer 7.0"
layout = "release"
type = "xenapi"
release = "dundee"
weight = 50
+++
