+++
title = "XenServer 5.6 FP1"
layout = "release"
type = "xenapi"
release = "cowley"
weight = 61
+++
