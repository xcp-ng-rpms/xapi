+++
title = "VM_guest_metrics"
layout = "class"
type = "xenapi"
class = "VM_guest_metrics"
+++
