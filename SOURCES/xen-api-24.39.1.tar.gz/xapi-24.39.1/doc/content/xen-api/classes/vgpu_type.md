+++
title = "VGPU_type"
layout = "class"
type = "xenapi"
class = "VGPU_type"
+++
