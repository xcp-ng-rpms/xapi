+++
title = "Cluster_host"
layout = "class"
type = "xenapi"
class = "Cluster_host"
+++
