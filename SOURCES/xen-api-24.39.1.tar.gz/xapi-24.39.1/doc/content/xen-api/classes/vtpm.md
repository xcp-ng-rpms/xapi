+++
title = "VTPM"
layout = "class"
type = "xenapi"
class = "VTPM"
+++
