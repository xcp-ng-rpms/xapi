+++
title = "VM_metrics"
layout = "class"
type = "xenapi"
class = "VM_metrics"
+++
