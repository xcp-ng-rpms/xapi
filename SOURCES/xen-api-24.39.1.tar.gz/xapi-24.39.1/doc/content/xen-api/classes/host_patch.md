+++
title = "host_patch"
layout = "class"
type = "xenapi"
class = "host_patch"
+++
