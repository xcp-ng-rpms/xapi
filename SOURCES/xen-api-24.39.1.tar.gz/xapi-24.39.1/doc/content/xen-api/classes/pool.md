+++
title = "pool"
layout = "class"
type = "xenapi"
class = "pool"
+++
