+++
title = "role"
layout = "class"
type = "xenapi"
class = "role"
+++
