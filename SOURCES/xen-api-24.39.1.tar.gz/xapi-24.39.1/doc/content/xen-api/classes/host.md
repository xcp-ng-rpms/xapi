+++
title = "host"
layout = "class"
type = "xenapi"
class = "host"
+++
