+++
title = "sr_stat"
layout = "class"
type = "xenapi"
class = "sr_stat"
+++
