+++
title = "PVS_server"
layout = "class"
type = "xenapi"
class = "PVS_server"
+++
