+++
title = "pool_update"
layout = "class"
type = "xenapi"
class = "pool_update"
+++
