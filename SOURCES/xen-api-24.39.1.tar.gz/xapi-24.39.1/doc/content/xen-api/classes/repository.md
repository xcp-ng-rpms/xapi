+++
title = "Repository"
layout = "class"
type = "xenapi"
class = "Repository"
+++
