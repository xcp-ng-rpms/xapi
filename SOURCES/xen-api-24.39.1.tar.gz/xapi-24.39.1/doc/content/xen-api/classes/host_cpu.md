+++
title = "host_cpu"
layout = "class"
type = "xenapi"
class = "host_cpu"
+++
