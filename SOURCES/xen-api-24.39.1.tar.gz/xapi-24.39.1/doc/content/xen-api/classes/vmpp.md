+++
title = "VMPP"
layout = "class"
type = "xenapi"
class = "VMPP"
+++
