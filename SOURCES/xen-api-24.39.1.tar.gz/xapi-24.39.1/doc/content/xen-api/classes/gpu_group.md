+++
title = "GPU_group"
layout = "class"
type = "xenapi"
class = "GPU_group"
+++
