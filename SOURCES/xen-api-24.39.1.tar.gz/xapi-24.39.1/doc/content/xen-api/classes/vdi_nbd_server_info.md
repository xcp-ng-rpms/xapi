+++
title = "vdi_nbd_server_info"
layout = "class"
type = "xenapi"
class = "vdi_nbd_server_info"
+++
