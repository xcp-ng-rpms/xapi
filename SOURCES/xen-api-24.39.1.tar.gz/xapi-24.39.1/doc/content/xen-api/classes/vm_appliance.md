+++
title = "VM_appliance"
layout = "class"
type = "xenapi"
class = "VM_appliance"
+++
