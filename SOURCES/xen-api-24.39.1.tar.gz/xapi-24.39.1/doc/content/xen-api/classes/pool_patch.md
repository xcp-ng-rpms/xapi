+++
title = "pool_patch"
layout = "class"
type = "xenapi"
class = "pool_patch"
+++
