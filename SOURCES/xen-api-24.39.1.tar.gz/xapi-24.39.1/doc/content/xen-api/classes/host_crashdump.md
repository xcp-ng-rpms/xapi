+++
title = "host_crashdump"
layout = "class"
type = "xenapi"
class = "host_crashdump"
+++
