+++
title = "Observer"
layout = "class"
type = "xenapi"
class = "Observer"
+++
