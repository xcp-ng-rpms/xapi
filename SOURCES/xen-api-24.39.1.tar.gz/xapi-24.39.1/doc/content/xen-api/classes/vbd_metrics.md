+++
title = "VBD_metrics"
layout = "class"
type = "xenapi"
class = "VBD_metrics"
+++
