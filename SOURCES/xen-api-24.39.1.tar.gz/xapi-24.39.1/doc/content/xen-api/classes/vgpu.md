+++
title = "VGPU"
layout = "class"
type = "xenapi"
class = "VGPU"
+++
