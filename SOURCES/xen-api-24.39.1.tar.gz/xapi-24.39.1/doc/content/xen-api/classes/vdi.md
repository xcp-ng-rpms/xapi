+++
title = "VDI"
layout = "class"
type = "xenapi"
class = "VDI"
+++
