+++
title = "VIF_metrics"
layout = "class"
type = "xenapi"
class = "VIF_metrics"
+++
