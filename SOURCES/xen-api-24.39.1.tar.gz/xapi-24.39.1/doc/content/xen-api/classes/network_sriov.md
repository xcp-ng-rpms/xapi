+++
title = "network_sriov"
layout = "class"
type = "xenapi"
class = "network_sriov"
+++
