+++
title = "VIF"
layout = "class"
type = "xenapi"
class = "VIF"
+++
