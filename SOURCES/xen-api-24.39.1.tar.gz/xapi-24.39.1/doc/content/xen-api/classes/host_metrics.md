+++
title = "host_metrics"
layout = "class"
type = "xenapi"
class = "host_metrics"
+++
