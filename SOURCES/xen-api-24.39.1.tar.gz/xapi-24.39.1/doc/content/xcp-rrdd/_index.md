+++
title = "RRDD"
+++

The `xcp-rrdd` daemon (hereafter simply called “rrdd”) is a component in the
xapi toolstack that is responsible for collecting metrics, storing them as
"Round-Robin Databases" (RRDs) and exposing these to clients.

The code is in ocaml/xcp-rrdd.