+++
title = "XAPI requests walk-throughs"
menuTitle = "Walk-throughs"
+++

Let's detail the handling process of an XML request within XAPI.
The first document uses the migration as an example of such request.

- [How the migration request goes through Xen API?](migration_overview.md)
